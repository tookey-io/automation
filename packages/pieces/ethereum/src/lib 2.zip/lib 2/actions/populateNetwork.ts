import {
    createAction
} from '@activepieces/pieces-framework';
import { CHAINS } from '../constants';
import { EthereumAuth } from '../../index';
import { createPublicClient, defineChain, http } from 'viem';

export const getNetwork = createAction({
    auth: EthereumAuth,
    requireAuth: true,
    name: 'getNetwork',
    displayName: 'Get Network',
    description: 'Returns the network data based on selected chain id',
    props: {},
    async run({ auth }) {
        const unknownChain = defineChain({
            name: 'Unknown',
            id: -1,
            rpcUrls: {
                default: {
                    http: [auth.rpc]
                },
                public: {
                    http: [auth.rpc]
                },
            },
            network: 'unknown',
            nativeCurrency: {
                name: 'Unknown Currency',
                symbol: 'CUR',
                decimals: 18
            }
        })
        
        const unknownClient = createPublicClient({
            chain: unknownChain,
            transport: http()
        })

        const id = await unknownClient.getChainId()
        const chain = Object.values(CHAINS).find((chain) => chain?.id === id)

        return defineChain({
            ...unknownChain,
            ...chain,
            rpcUrls: {
                default: {
                    http: [auth.rpc]
                },
                public: {
                    http: [auth.rpc]
                },
            },
        })
    },
});
